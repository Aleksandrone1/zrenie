package com.example.zrenie4;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.zrenie4.models.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Registration2 extends AppCompatActivity {
    Button vnes;
    EditText email,name,pass,phone;
    String email1,name1,pass1,phone1;
    FirebaseAuth auth;
    FirebaseDatabase db;
    DatabaseReference users;
    RelativeLayout relativeLayout;
    User user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reg);
        vnes=findViewById(R.id.button8);
        auth=FirebaseAuth.getInstance();
        db=FirebaseDatabase.getInstance();
        users= db.getReference("Users");
        email=findViewById(R.id.email_field);
        pass=findViewById(R.id.pass_field);
        name=findViewById(R.id.name);
        phone=findViewById(R.id.numbertelephone);
        user=new User();
        vnes.setOnClickListener(view -> showRegisterWindow());
    }
    private void showRegisterWindow() {
        email1 =email.getText().toString(); //даные с которых будет считывается данные
        pass1 = pass.getText().toString();
        name1 = name.getText().toString();
        phone1=phone.getText().toString();
        if(TextUtils.isEmpty(email1)){
            Toast.makeText(Registration2.this,"Введите почту",Toast.LENGTH_LONG).show();
        }
        if(TextUtils.isEmpty(pass1)){
            Toast.makeText(Registration2.this,"Введите пароль",Toast.LENGTH_LONG).show();
        }
        if(TextUtils.isEmpty(name1)){
            Toast.makeText(Registration2.this,"Введите имя",Toast.LENGTH_LONG).show();
        }
        if(TextUtils.isEmpty(phone1)){
            Toast.makeText(Registration2.this,"Введите телефон",Toast.LENGTH_LONG).show();
        }else{
           User user = new User(email1, pass1, name1, phone1);
            auth.createUserWithEmailAndPassword(email.getText().toString(),pass.getText().toString()).addOnSuccessListener(authResult ->
                    users.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(user).addOnSuccessListener(unused -> Toast.makeText(Registration2.this, "Пользователь добавлен", Toast.LENGTH_LONG).show()));
        }
    }
}